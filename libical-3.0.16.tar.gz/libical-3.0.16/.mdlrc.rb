all
rule 'MD013', :line_length => 100
rule 'MD029', :style => :ordered
exclude_rule 'MD033'
