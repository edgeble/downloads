#ifndef MESON_INCLUDE_IMPL
#error "MESON_INCLUDE_IMPL is not defined"
#endif // !MESON_INCLUDE_IMPL

string cmModClass::getStr1() const {
  return getStr2();
}
