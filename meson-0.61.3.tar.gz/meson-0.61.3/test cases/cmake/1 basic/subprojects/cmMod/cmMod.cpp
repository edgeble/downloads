#include "cmMod.hpp"

using namespace std;

#if MESON_MAGIC_FLAG != 21
#error "Invalid MESON_MAGIC_FLAG (private)"
#endif

cmModClass::cmModClass(string foo) {
  str = foo + " World";
}

string cmModClass::getStr() const {
  return str;
}
