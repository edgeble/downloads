int func4_in_obj(void) {
    return 0;
}
