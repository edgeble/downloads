#include<stdio.h>

int main(void) {
    printf("Existentialism.\n");
    return 0;
}
